import { Component, OnInit } from '@angular/core';
import {CdkDragDrop, moveItemInArray, transferArrayItem} from '@angular/cdk/drag-drop';
import { ToastrService } from 'ngx-toastr';

// import { $ } from 'protractor';
declare var $:any
@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.scss']
})
export class AddUserComponent implements OnInit {
  userData:any = []
  taskData =[]
  username: any;
  value = ''
  taskvalue = ''
  index: any;
  constructor(private toastr: ToastrService) { }

  ngOnInit(): void {
  }

  openuserpopup(){
    this.value = ''
  }
 
  adduser() {
    console.log(this.value);
    if (!this.value) {
      console.log(this.value);
      this.toastr.error('Please Enter User Name!', 'Error!');
      return
    }
    else {
      let data = {
        username: this.value
      }
      this.userData.push(data)
      console.log(this.userData)
      $('#adduser').modal('hide')
      this.toastr.success('User add successfully!', 'Success!');

    }
  }

  addtaskpopup(i){
    $('#addtask').modal('show')
    this.index = i
    console.log(i,this.index)
    this.taskvalue =''
  }

  addTask(){
    if (!this.taskvalue) {
      this.toastr.error('Please Enter Task!', 'Error!');
      return
    }
    else {
      var task = {
        taskname:this.taskvalue
      }
      if(this.userData[this.index].task){
        this.userData[this.index].task.push(this.taskvalue)
      }
      else{
        this.userData[this.index].task= []
        this.userData[this.index].task.push(this.taskvalue)
      }
      $('#addtask').modal('hide')
      this.toastr.success('User add successfully!', 'Success!');

    }
  
    console.log(this.userData)
  }
  drop(event: CdkDragDrop<string[]>) {
    if (event.previousContainer === event.container) {
      moveItemInArray(event.container.data, event.previousIndex, event.currentIndex);
    } else {
      transferArrayItem(event.previousContainer.data,
                        event.container.data,
                        event.previousIndex,
                        event.currentIndex);
    }
  }
  remove(i){
    this.userData.splice(i,1)
  }
}
